import pygame
import random
import os

# Initialize Pygame
pygame.init()

# Set up the display
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("2D Driving Game")

# Colors
GRAY = (100, 100, 100)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Car properties (Porsche 911 G8 specs)
MAX_SPEED = 191  # mph
ENGINE_RPM_LIMIT = 7500  # Max RPM
ACCELERATION = 0.5
DECELERATION = 0.25
STEERING_SPEED = 0.1
MAX_TURN = 5
NUM_CYLINDERS = 6  # 6 cylinders for the Porsche 911 G8

# Gear system
NUM_GEARS = 7  # 7-speed manual transmission
GEAR_SPEEDS = [30, 60, 90, 120, 150, 180, 191]  # Maximum speed for each gear
GEAR_RPM_RANGES = [(0, 7500)] * NUM_GEARS  # RPM ranges for each gear (fixed at 7500)
current_gear = 1

# Engine braking deceleration
ENGINE_BRAKING_DECELERATION = 1.0

# Game state
car_speed = 0
car_angle = 0
rpm = 0
lane_offset = 0
road_offset = 0  # This will control the offset of the lines as the car moves down
line_height = 50  # Height between lines

# Load car sprites from the ./car_sprites directory
def load_car_sprites():
    sprites = []
    for file in os.listdir('./car_sprites'):
        if file.endswith(".png"):
            sprites.append(os.path.join('./car_sprites', file))
    return sprites

# Load car images
car_sprites = load_car_sprites()
current_sprite_index = 0  # Track the current sprite index

# Load the initial car image
car_img = pygame.image.load(car_sprites[current_sprite_index])
car_rect = car_img.get_rect()
car_scale = min(WIDTH / 5 / car_rect.width, HEIGHT / 5 / car_rect.height)
car_img = pygame.transform.scale(car_img, (int(car_rect.width * car_scale), int(car_rect.height * car_scale)))
car_rect = car_img.get_rect()

# Road properties
LANE_WIDTH = 100

# Font for displaying text
font = pygame.font.Font(None, 36)

# Button class
class Button:
    def __init__(self, x, y, width, height, text, color):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = color

    def draw(self, surface):
        pygame.draw.rect(surface, self.color, self.rect)
        text_surf = font.render(self.text, True, BLACK)
        text_rect = text_surf.get_rect(center=self.rect.center)
        surface.blit(text_surf, text_rect)

    def is_clicked(self, pos):
        return self.rect.collidepoint(pos)

# Create buttons
increase_speed_btn = Button(WIDTH - 150, 10, 140, 40, "Speed +10", GREEN)
decrease_speed_btn = Button(WIDTH - 150, 60, 140, 40, "Speed -10", RED)
increase_rpm_btn = Button(WIDTH - 150, 110, 140, 40, "RPM +500", GREEN)
decrease_rpm_btn = Button(WIDTH - 150, 160, 140, 40, "RPM -500", RED)
increase_gears_btn = Button(WIDTH - 150, 210, 140, 40, "Gears +1", GREEN)
decrease_gears_btn = Button(WIDTH - 150, 260, 140, 40, "Gears -1", RED)
increase_cylinders_btn = Button(WIDTH - 150, 310, 140, 40, "Cyl +1", GREEN)
decrease_cylinders_btn = Button(WIDTH - 150, 360, 140, 40, "Cyl -1", RED)

# Game loop
running = True
clock = pygame.time.Clock()

def calculate_acceleration(speed, gear):
    global NUM_CYLINDERS
    gear_max_speed = GEAR_SPEEDS[gear - 1]
    acceleration_factor = 1 - (speed / gear_max_speed) ** 2
    cylinder_factor = NUM_CYLINDERS / 6  # Baseline is 6 cylinders
    return ACCELERATION * acceleration_factor * cylinder_factor

def shift_gear(direction):
    global current_gear, car_speed, rpm
    new_gear = max(1, min(NUM_GEARS, current_gear + direction))

    if new_gear != current_gear:
        if direction > 0:  # Shifting up
            if rpm >= 7500:
                current_gear = new_gear
                rpm = GEAR_RPM_RANGES[current_gear - 1][0]  # Set to min RPM of the new gear
            else:
                # Check the RPM and adjust speed based on conditions
                if rpm > GEAR_RPM_RANGES[current_gear - 1][1]:  # If RPM is above new gear limit
                    rpm = GEAR_RPM_RANGES[current_gear - 1][1]  # Set RPM to limit
                    car_speed = GEAR_SPEEDS[current_gear - 1]  # Set speed to max of new gear
                current_gear = new_gear

        else:  # Shifting down
            if rpm > GEAR_RPM_RANGES[current_gear - 1][1]:  # If RPM is above new gear limit
                rpm = GEAR_RPM_RANGES[current_gear - 1][1]  # Set RPM to limit
                car_speed = GEAR_SPEEDS[current_gear - 1]  # Set speed to max of new gear
            current_gear = new_gear
            rpm = GEAR_RPM_RANGES[current_gear - 1][1]  # Set to max RPM of the new gear

def update_car_parameters():
    global GEAR_SPEEDS, GEAR_RPM_RANGES, NUM_GEARS
    gear_step = MAX_SPEED / NUM_GEARS
    GEAR_SPEEDS = [int(gear_step * (i + 1)) for i in range(NUM_GEARS)]
    rpm_step = ENGINE_RPM_LIMIT / NUM_GEARS
    GEAR_RPM_RANGES = [(0, int(ENGINE_RPM_LIMIT - i * rpm_step)) for i in range(NUM_GEARS)]

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_x:
                shift_gear(1)  # Shift up
            elif event.key == pygame.K_z:
                shift_gear(-1)  # Shift down
            elif event.key == pygame.K_r:  # Press 'R' to toggle left
                current_sprite_index = (current_sprite_index - 1) % len(car_sprites)
                car_img = pygame.image.load(car_sprites[current_sprite_index])
                car_rect = car_img.get_rect()
                car_img = pygame.transform.scale(car_img, (int(car_rect.width * car_scale), int(car_rect.height * car_scale)))
                car_rect = car_img.get_rect()
            elif event.key == pygame.K_t:  # Press 'T' to toggle right
                current_sprite_index = (current_sprite_index + 1) % len(car_sprites)
                car_img = pygame.image.load(car_sprites[current_sprite_index])
                car_rect = car_img.get_rect()
                car_img = pygame.transform.scale(car_img, (int(car_rect.width * car_scale), int(car_rect.height * car_scale)))
                car_rect = car_img.get_rect()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            if increase_speed_btn.is_clicked(pos):
                MAX_SPEED += 10
                update_car_parameters()
            elif decrease_speed_btn.is_clicked(pos):
                MAX_SPEED = max(MAX_SPEED - 10, 10)  # Minimum speed of 10 mph
                update_car_parameters()
            elif increase_rpm_btn.is_clicked(pos):
                ENGINE_RPM_LIMIT += 500
                update_car_parameters()
            elif decrease_rpm_btn.is_clicked(pos):
                ENGINE_RPM_LIMIT = max(ENGINE_RPM_LIMIT - 500, 1000)  # Minimum RPM of 1000
                update_car_parameters()
            elif increase_gears_btn.is_clicked(pos):
                NUM_GEARS += 1
                update_car_parameters()
            elif decrease_gears_btn.is_clicked(pos):
                NUM_GEARS = max(NUM_GEARS - 1, 1)
                update_car_parameters()
            elif increase_cylinders_btn.is_clicked(pos):
                NUM_CYLINDERS += 1
                update_car_parameters()
            elif decrease_cylinders_btn.is_clicked(pos):
                NUM_CYLINDERS = max(NUM_CYLINDERS - 1, 1)
                update_car_parameters()

    # Handle acceleration
    keys = pygame.key.get_pressed()
    if keys[pygame.K_UP] or keys[pygame.K_w]:
        acceleration = calculate_acceleration(car_speed, current_gear)
        car_speed = min(car_speed + acceleration, MAX_SPEED)
        rpm = min(rpm + (acceleration * 100), ENGINE_RPM_LIMIT)  # Increase RPM based on acceleration

    if keys[pygame.K_DOWN] or keys[pygame.K_s]:
        car_speed = max(car_speed - DECELERATION, 0)
        rpm = max(rpm - (ENGINE_BRAKING_DECELERATION * 100), 0)  # Decrease RPM

    if keys[pygame.K_LEFT]:
        lane_offset = max(-LANE_WIDTH / 2, lane_offset - STEERING_SPEED)
    if keys[pygame.K_RIGHT]:
        lane_offset = min(LANE_WIDTH / 2, lane_offset + STEERING_SPEED)

    # Update road offset based on car speed (flows upward)
    road_offset -= car_speed * 15 * (1 / 60)  # Increased multiplier for road flow
    if road_offset <= -line_height:  # When the offset exceeds the height of a line
        road_offset += line_height  # Reset offset to draw new line

    # Draw everything
    screen.fill(GRAY)

    # Draw the road and lanes as lines
    for lane in range(-LANE_WIDTH, WIDTH + LANE_WIDTH, LANE_WIDTH):
        # Draw lines based on the current road offset
        for y in range(-line_height, HEIGHT + line_height, line_height):
            pygame.draw.line(screen, WHITE, (lane + lane_offset + LANE_WIDTH // 2, y + road_offset), 
                             (lane + lane_offset + LANE_WIDTH // 2, y + road_offset + 20), 3)

    # Draw the car
    screen.blit(car_img, car_rect.topleft)

    # Draw buttons
    increase_speed_btn.draw(screen)
    decrease_speed_btn.draw(screen)
    increase_rpm_btn.draw(screen)
    decrease_rpm_btn.draw(screen)
    increase_gears_btn.draw(screen)
    decrease_gears_btn.draw(screen)
    increase_cylinders_btn.draw(screen)
    decrease_cylinders_btn.draw(screen)

    # Draw speed and RPM in the bottom right corner
    speed_text = font.render(f"Speed: {int(car_speed)} mph (Max: {MAX_SPEED})", True, BLACK)
    rpm_text = font.render(f"RPM: {int(rpm)} (Max: {ENGINE_RPM_LIMIT})", True, BLACK)
    gear_text = font.render(f"Gear: {current_gear}/{NUM_GEARS}", True, BLACK)
    cylinders_text = font.render(f"Cylinders: {NUM_CYLINDERS}", True, BLACK)

    screen.blit(speed_text, (WIDTH - speed_text.get_width() - 10, HEIGHT - 140))
    screen.blit(rpm_text, (WIDTH - rpm_text.get_width() - 10, HEIGHT - 100))
    screen.blit(gear_text, (WIDTH - gear_text.get_width() - 10, HEIGHT - 60))
    screen.blit(cylinders_text, (WIDTH - cylinders_text.get_width() - 10, HEIGHT - 20))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()

